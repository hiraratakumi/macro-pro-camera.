import 'dart:io';
import 'package:image/image.dart' as img;

class PhotoEditorService {
  /// Penyesuaian warna gaya Lightroom (Brightness, Contrast, Saturation)
  Future<File> adjustColor({
    required String imagePath,
    required double brightness, // -1.0 sampai 1.0
    required double contrast,   // 0.0 sampai 2.0
    required double saturation, // 0.0 sampai 2.0
  }) async {
    final bytes = await File(imagePath).readAsBytes();
    img.Image? image = img.decodeImage(bytes);
    if (image == null) return File(imagePath);

    // Atur Kecerahan & Kontras
    image = img.adjustColor(
      image,
      brightness: brightness,
      contrast: contrast,
      saturation: saturation,
    );

    final outputFile = File(imagePath);
    await outputFile.writeAsBytes(img.encodeJpg(image, quality: 95));
    return outputFile;
  }
}
