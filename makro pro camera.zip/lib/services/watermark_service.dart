import 'dart:io';
import 'package:image/image.dart' as img;

class WatermarkService {
  /// Menambahkan watermark teks ke file gambar
  Future<File?> addWatermark({
    required String imagePath,
    required String watermarkText,
  }) async {
    final imageBytes = await File(imagePath).readAsBytes();
    img.Image? originalImage = img.decodeImage(imageBytes);

    if (originalImage == null) return null;

    // Gambar teks di pojok kanan bawah
    img.drawString(
      originalImage,
      watermarkText,
      font: img.arial24,
      x: originalImage.width - 300,
      y: originalImage.height - 50,
      color: img.ColorRgb8(255, 255, 255),
    );

    final watermarkedBytes = img.encodeJpg(originalImage, quality: 95);
    final watermarkedFile = File(imagePath);
    await watermarkedFile.writeAsBytes(watermarkedBytes);

    return watermarkedFile;
  }
}
