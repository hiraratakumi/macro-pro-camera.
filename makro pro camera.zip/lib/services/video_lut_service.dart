import 'package:ffmpeg_kit_flutter_full_gpl/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_full_gpl/return_code.dart';

class VideoLutService {
  /// Mengaplikasikan filter 3D LUT (Hollywood Cinema Style) ke file video
  Future<String?> applyLutToVideo({
    required String inputVideoPath,
    required String lutFilePath,
    required String outputPath,
  }) async {
    // Jalankan perintah FFmpeg untuk color grading menggunakan file LUT .cube
    String command = "-i '$inputVideoPath' -vf lut3d='$lutFilePath' -c:a copy '$outputPath'";

    final session = await FFmpegKit.execute(command);
    final returnCode = await session.getReturnCode();

    if (ReturnCode.isSuccess(returnCode)) {
      return outputPath;
    } else {
      return null;
    }
  }
}
