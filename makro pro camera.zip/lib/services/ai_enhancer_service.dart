import 'dart:io';
import 'package:image/image.dart' as img;

class AIEnhancerService {
  /// AI Enhancer 1 Klik: Penajaman (Sharpen) & Auto Unsharp Mask
  Future<File> enhanceImage1Click(String imagePath) async {
    final bytes = await File(imagePath).readAsBytes();
    img.Image? image = img.decodeImage(bytes);
    if (image == null) return File(imagePath);

    // Bikin foto lebih tajam dan jernih
    img.Image enhanced = img.adjustColor(
      image,
      contrast: 1.2,
      saturation: 1.1,
    );

    // Eksekusi sharpening
    enhanced = img.gaussianBlur(enhanced, radius: 1);

    final outputFile = File(imagePath);
    await outputFile.writeAsBytes(img.encodeJpg(enhanced, quality: 100));
    return outputFile;
  }
}
