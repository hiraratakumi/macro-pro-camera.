import 'dart:io';
import 'package:camera/camera.dart';
import 'camera_service.dart';

class FocusStackingService {
  final CameraService cameraService;

  FocusStackingService({required this.cameraService});

  /// Mengambil serangkaian foto dengan variasi jarak fokus (Focus Stacking)
  /// [steps]: Jumlah foto yang diambil (default 5 foto)
  /// [delayMillis]: Jeda antar foto dalam milidetik agar lensa sempat menyesuaikan posisi
  Future<List<String>> captureFocusStackSequence({
    int steps = 5,
    int delayMillis = 300,
  }) async {
    List<String> capturedPaths = [];
    final controller = cameraService.controller;

    if (controller == null || !controller.value.isInitialized) {
      return capturedPaths;
    }

    try {
      // Set kamera ke mode fokus manual agar nilai jarak fokus dapat diatur secara presisi
      await cameraService.setFocusMode(FocusMode.locked);

      // Hitung pergeseran nilai fokus dari terdekat (0.0) hingga terjauh (1.0)
      for (int i = 0; i < steps; i++) {
        double focusPoint = i / (steps - 1);
        
        // Atur posisi fokus lensa
        await controller.setFocusPoint(Offset(0.5, focusPoint));

        // Beri waktu hardware lensa untuk berpindah posisi
        await Future.delayed(Duration(milliseconds: delayMillis));

        // Ambil foto pada jarak fokus saat ini
        XFile? photo = await cameraService.takePicture();
        if (photo != null) {
          capturedPaths.add(photo.path);
        }
      }
    } catch (e) {
      // Kembalikan ke mode fokus otomatis jika terjadi kendala
      await cameraService.setFocusMode(FocusMode.auto);
      rethrow;
    } finally {
      // Kembalikan mode fokus ke otomatis setelah proses selesai
      await cameraService.setFocusMode(FocusMode.auto);
    }

    return capturedPaths;
  }
}
