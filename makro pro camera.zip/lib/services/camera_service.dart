import 'package:camera/camera.dart';

class CameraService {
  CameraController? controller;

  Future<void> initializeCamera(CameraDescription camera) async {
    controller = CameraController(
      camera,
      ResolutionPreset.max,
      enableAudio: false,
      imageFormatGroup: ImageFormatGroup.jpeg,
    );

    await controller!.initialize();
  }

  Future<void> setFocusMode(FocusMode mode) async {
    if (controller != null && controller!.value.isInitialized) {
      await controller!.setFocusMode(mode);
    }
  }

  Future<void> setFlashMode(FlashMode mode) async {
    if (controller != null && controller!.value.isInitialized) {
      await controller!.setFlashMode(mode);
    }
  }

  Future<void> setExposureOffset(double offset) async {
    if (controller != null && controller!.value.isInitialized) {
      await controller!.setExposureOffset(offset);
    }
  }

  Future<XFile?> takePicture() async {
    if (controller != null && controller!.value.isInitialized) {
      if (controller!.value.isTakingPicture) return null;
      return await controller!.takePicture();
    }
    return null;
  }

  void dispose() {
    controller?.dispose();
  }
}
