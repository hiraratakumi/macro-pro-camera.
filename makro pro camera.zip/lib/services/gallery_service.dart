import 'dart:io';
import 'package:path_provider/path_provider.dart';

class GalleryService {
  /// Mendapatkan direktori penyimpanan lokal khusus aplikasi
  Future<Directory> get _localPath async {
    final directory = await getApplicationDocumentsDirectory();
    final mediaDir = Directory('${directory.path}/MacroCameraPhotos');
    if (!await mediaDir.exists()) {
      await mediaDir.create(recursive: true);
    }
    return mediaDir;
  }

  /// Mengambil semua daftar foto yang tersimpan
  Future<List<FileSystemEntity>> fetchLocalPhotos() async {
    final dir = await _localPath;
    return dir.listSync().where((file) => file.path.endsWith('.jpg')).toList();
  }

  /// Memindahkan file foto dari cache ke direktori penyimpanan lokal
  Future<File> savePhotoToLocal(String tempPath) async {
    final dir = await _localPath;
    final String fileName = 'MACRO_${DateTime.now().millisecondsSinceEpoch}.jpg';
    final File tempFile = File(tempPath);
    return await tempFile.copy('${dir.path}/$fileName');
  }
}
