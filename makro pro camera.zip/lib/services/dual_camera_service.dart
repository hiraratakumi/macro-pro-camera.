import 'package:camera/camera.dart';

class DualCameraService {
  CameraController? frontController;
  CameraController? backController;

  Future<void> initializeDualCameras(List<CameraDescription> cameras) async {
    CameraDescription? backCam;
    CameraDescription? frontCam;

    for (var cam in cameras) {
      if (cam.lensDirection == CameraLensDirection.back && backCam == null) {
        backCam = cam;
      } else if (cam.lensDirection == CameraLensDirection.front && frontCam == null) {
        frontCam = cam;
      }
    }

    if (backCam != null) {
      backController = CameraController(backCam, ResolutionPreset.high, enableAudio: true);
      await backController!.initialize();
    }

    if (frontCam != null) {
      frontController = CameraController(frontCam, ResolutionPreset.high, enableAudio: true);
      await frontController!.initialize();
    }
  }

  Future<void> startDualRecord() async {
    if (backController != null && backController!.value.isInitialized) {
      await backController!.startVideoRecording();
    }
    if (frontController != null && frontController!.value.isInitialized) {
      await frontController!.startVideoRecording();
    }
  }

  Future<List<XFile>> stopDualRecord() async {
    List<XFile> files = [];
    if (backController != null && backController!.value.isRecordingVideo) {
      files.add(await backController!.stopVideoRecording());
    }
    if (frontController != null && frontController!.value.isRecordingVideo) {
      files.add(await frontController!.stopVideoRecording());
    }
    return files;
  }

  void dispose() {
    backController?.dispose();
    frontController?.dispose();
  }
}
