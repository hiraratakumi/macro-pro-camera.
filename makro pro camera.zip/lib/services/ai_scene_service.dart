import 'package:google_mlkit_object_detection/google_mlkit_object_detection.dart';

class AISceneService {
  late ObjectDetector _objectDetector;

  AISceneService() {
    final options = ObjectDetectorOptions(
      mode: DetectionMode.stream,
      classifyObjects: true,
      multipleObjects: true,
    );
    _objectDetector = ObjectDetector(options: options);
  }

  Future<String> detectScene(InputImage inputImage) async {
    try {
      final objects = await _objectDetector.processImage(inputImage);
      if (objects.isEmpty) return "Auto";

      for (final detectedObject in objects) {
        for (final label in detectedObject.labels) {
          final text = label.text.toLowerCase();
          if (text.contains('food')) return "Makanan";
          if (text.contains('person') || text.contains('face')) return "Potret";
          if (text.contains('plant') || text.contains('flower')) return "Makro / Alam";
          if (text.contains('sky')) return "Langit";
        }
      }
      return "Auto";
    } catch (e) {
      return "Auto";
    }
  }

  void dispose() {
    _objectDetector.close();
  }
}
