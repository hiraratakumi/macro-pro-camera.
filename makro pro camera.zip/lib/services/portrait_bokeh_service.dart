import 'dart:io';
import 'package:image/image.dart' as img;

class PortraitBokehService {
  /// Mengaplikasikan efek blur (bokeh) background berdasarkan simulasi aperture
  Future<File> applyBokeh({
    required String imagePath,
    required double aperture, // F1.2 (blur tinggi) sampai F16 (blur rendah)
  }) async {
    final bytes = await File(imagePath).readAsBytes();
    img.Image? original = img.decodeImage(bytes);
    if (original == null) return File(imagePath);

    // Hitung radius blur dari aperture (F1.2 -> radius besar, F16 -> radius kecil)
    int blurRadius = ((16.0 - aperture) * 2).clamp(1, 30).toInt();

    // Lakukan gaussian blur untuk latar belakang
    img.Image blurred = img.gaussianBlur(original.clone(), radius: blurRadius);

    final outputFile = File(imagePath);
    await outputFile.writeAsBytes(img.encodeJpg(blurred, quality: 95));
    return outputFile;
  }
}
