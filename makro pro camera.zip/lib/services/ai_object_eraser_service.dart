import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;

class AIObjectEraserService {
  /// Menghapus area objek yang diusap pengguna menggunakan Inpainting Sederhana
  Future<File> eraseObject({
    required String imagePath,
    required Rect eraseArea,
  }) async {
    final bytes = await File(imagePath).readAsBytes();
    img.Image? image = img.decodeImage(bytes);
    if (image == null) return File(imagePath);

    int startX = eraseArea.left.toInt().clamp(0, image.width);
    int startY = eraseArea.top.toInt().clamp(0, image.height);
    int width = eraseArea.width.toInt().clamp(1, image.width - startX);
    int height = eraseArea.height.toInt().clamp(1, image.height - startY);

    // Ambil warna sekitar area untuk penutupan objek
    img.Pixel neighborColor = image.getPixel(
      (startX - 5).clamp(0, image.width - 1),
      (startY - 5).clamp(0, image.height - 1),
    );

    // Isi area yang diusap dengan piksel sekitar
    for (int y = startY; y < startY + height; y++) {
      for (int x = startX; x < startX + width; x++) {
        image.setPixel(x, y, neighborColor);
      }
    }

    // Blur sedikit area editan agar mulus
    image = img.gaussianBlur(image, radius: 3);

    final outputFile = File(imagePath);
    await outputFile.writeAsBytes(img.encodeJpg(image, quality: 95));
    return outputFile;
  }
}
