import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import '../services/camera_service.dart';
import '../services/focus_stacking_service.dart';
import '../widgets/camera_overlay_widget.dart';
import '../widgets/manual_controls_widget.dart';

class CameraScreen extends StatefulWidget {
  final List<CameraDescription> cameras;

  const CameraScreen({super.key, required this.cameras});

  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  final CameraService _cameraService = CameraService();
  late FocusStackingService _focusStackingService;
  
  bool _isInitialized = false;
  bool _isCapturingStack = false;
  double _currentEV = 0.0;
  double _minEV = -2.0;
  double _maxEV = 2.0;
  bool _isFlashOn = false;

  @override
  void initState() {
    super.initState();
    _focusStackingService = FocusStackingService(cameraService: _cameraService);
    _setupCamera();
  }

  Future<void> _setupCamera() async {
    if (widget.cameras.isNotEmpty) {
      await _cameraService.initializeCamera(widget.cameras.first);
      final controller = _cameraService.controller;
      if (controller != null) {
        _minEV = await controller.getMinExposureOffset();
        _maxEV = await controller.getMaxExposureOffset();
      }
      if (mounted) {
        setState(() {
          _isInitialized = true;
        });
      }
    }
  }

  @override
  void dispose() {
    _cameraService.dispose();
    super.dispose();
  }

  /// Eksekusi Focus Stacking
  Future<void> _startFocusStacking() async {
    setState(() {
      _isCapturingStack = true;
    });

    try {
      // Mengambil 5 foto dengan layer fokus berbeda
      List<String> photos = await _focusStackingService.captureFocusStackSequence(
        steps: 5,
        delayMillis: 350,
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Focus Stacking selesai! ${photos.length} foto berhasil diambil.'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Gagal mengambil Focus Stack: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isCapturingStack = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_isInitialized || _cameraService.controller == null) {
      return const Scaffold(
        backgroundColor: Colors.black,
        body: Center(child: CircularProgressIndicator(color: Colors.amber)),
      );
    }

    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Stack(
          children: [
            Positioned.fill(
              child: CameraPreview(_cameraService.controller!),
            ),
            const CameraOverlayWidget(showGrid: true),

            // Indikator saat proses Focus Stacking berlangsung
            if (_isCapturingStack)
              Container(
                color: Colors.black54,
                child: const Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CircularProgressIndicator(color: Colors.amber),
                      SizedBox(height: 16),
                      Text(
                        'Mengambil Foto Focus Stacking...\nTahan posisi HP agar tidak bergeser',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
              ),

            Align(
              alignment: Alignment.bottomCenter,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  ManualControlsWidget(
                    currentEV: _currentEV,
                    minEV: _minEV,
                    maxEV: _maxEV,
                    onEVChanged: (val) {
                      setState(() => _currentEV = val);
                      _cameraService.setExposureOffset(val);
                    },
                    isFlashOn: _isFlashOn,
                    onToggleFlash: () {
                      setState(() => _isFlashOn = !_isFlashOn);
                      _cameraService.setFlashMode(
                        _isFlashOn ? FlashMode.torch : FlashMode.off,
                      );
                    },
                  ),
                  const SizedBox(height: 12),

                  // Tombol Khusus Focus Stacking Auto
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.amber,
                      foregroundColor: Colors.black,
                    ),
                    onPressed: _isCapturingStack ? null : _startFocusStacking,
                    icon: const Icon(Icons.layers),
                    label: const Text('AUTO FOCUS STACK (5 FOTO)'),
                  ),

                  const SizedBox(height: 16),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
