import 'dart:io';
import 'package:flutter/material.dart';

class GalleryScreen extends StatelessWidget {
  final List<FileSystemEntity> photoFiles;

  const GalleryScreen({super.key, required this.photoFiles});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Galeri Hasil Makro'),
        backgroundColor: Colors.black87,
      ),
      body: photoFiles.isEmpty
          ? const Center(
              child: Text(
                'Belum ada foto makro yang disimpan',
                style: TextStyle(color: Colors.white54),
              ),
            )
          : GridView.builder(
              padding: const EdgeInsets.all(8.0),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                crossAxisSpacing: 8,
                mainAxisSpacing: 8,
              ),
              itemCount: photoFiles.length,
              itemBuilder: (context, index) {
                return ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.file(
                    File(photoFiles[index].path),
                    fit: BoxFit.cover,
                  ),
                );
              },
            ),
    );
  }
}
