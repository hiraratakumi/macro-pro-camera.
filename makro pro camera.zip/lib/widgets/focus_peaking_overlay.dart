import 'package:flutter/material.dart';

class FocusPeakingOverlay extends StatelessWidget {
  final Offset? tapPosition;
  final bool isFocusing;

  const FocusPeakingOverlay({
    super.key,
    this.tapPosition,
    this.isFocusing = false,
  });

  @override
  Widget build(BuildContext context) {
    if (tapPosition == null) return const SizedBox.shrink();

    return Positioned(
      left: tapPosition!.dx - 40,
      top: tapPosition!.dy - 40,
      child: IgnorePointer(
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          width: 80,
          height: 80,
          decoration: BoxDecoration(
            border: Border.all(
              color: isFocusing ? Colors.amber : Colors.greenAccent,
              width: 2,
            ),
            shape: BoxShape.rectangle,
            borderRadius: BorderRadius.circular(8),
          ),
          child: const Center(
            child: Icon(
              Icons.center_focus_strong,
              color: Colors.amber,
              size: 24,
            ),
          ),
        ),
      ),
    );
  }
}
