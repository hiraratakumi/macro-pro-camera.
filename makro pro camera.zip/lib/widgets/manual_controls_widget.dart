import 'package:flutter/material.dart';

class ManualControlsWidget extends StatelessWidget {
  final double currentEV;
  final double minEV;
  final double maxEV;
  final ValueChanged<double> onEVChanged;
  final VoidCallback onToggleFlash;
  final bool isFlashOn;

  const ManualControlsWidget({
    super.key,
    required this.currentEV,
    required this.minEV,
    required this.maxEV,
    required this.onEVChanged,
    required this.onToggleFlash,
    required this.isFlashOn,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black87,
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              const Text("EV", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              Expanded(
                child: Slider(
                  value: currentEV,
                  min: minEV,
                  max: maxEV,
                  activeColor: Colors.amber,
                  onChanged: onEVChanged,
                ),
              ),
              Text(
                currentEV.toStringAsFixed(1),
                style: const TextStyle(color: Colors.white),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              IconButton(
                icon: Icon(
                  isFlashOn ? Icons.flash_on : Icons.flash_off,
                  color: isFlashOn ? Colors.amber : Colors.white,
                ),
                onPressed: onToggleFlash,
              ),
            ],
          ),
        ],
      ),
    );
  }
}
