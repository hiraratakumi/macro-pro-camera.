import 'package:flutter/material.dart';

class CameraOverlayWidget extends StatelessWidget {
  final bool showGrid;

  const CameraOverlayWidget({super.key, this.showGrid = true});

  @override
  Widget build(BuildContext context) {
    if (!showGrid) return const SizedBox.shrink();

    return IgnorePointer(
      child: Stack(
        children: [
          Column(
            children: [
              Expanded(child: Container()),
              const Divider(color: Colors.white30, height: 1),
              Expanded(child: Container()),
              const Divider(color: Colors.white30, height: 1),
              Expanded(child: Container()),
            ],
          ),
          Row(
            children: [
              Expanded(child: Container()),
              const VerticalDivider(color: Colors.white30, width: 1),
              Expanded(child: Container()),
              const VerticalDivider(color: Colors.white30, width: 1),
              Expanded(child: Container()),
            ],
          ),
        ],
      ),
    );
  }
}
